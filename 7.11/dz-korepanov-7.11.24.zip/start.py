#task1
a = int(input('a -> '))
b = int(input('b -> '))
c = int(input('c -> '))
print('++ = ',a + b + c)
print('** = ',a * b * c)

print()
#task2
a = int(input('зп -> '))
b = int(input('кредит -> '))
c = int(input('комуналка -> '))
print('осталось',a - b - c, 'шекелей')

print()
#task3
a = int(input('diag1 -> '))
b = int(input('diag2 -> '))
print('S =',(a*b)/2)

print()
#task4
print('To be')
print('or not')
print('to be')

print()
#task5
a = '    '
print('“Life is what happens')
print(a+'when')
print(a*2+'you’re busy making other plans”')
print(a*9+'John Lennon.')